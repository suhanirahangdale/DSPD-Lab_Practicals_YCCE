#include <stdio.h>

int main() {
    FILE *f1, *f2;
    char ch;

    f1 = fopen("input.txt", "r");
    f2 = fopen("output.txt", "w");

    if(f1 == NULL) {
        printf("Error: input.txt file does not exist.\n");
        return 1;
    }
    while((ch = fgetc(f1)) != EOF) {
        fputc(ch, f2);
    }
    printf("File copied successfully.\n");

    fclose(f1);
    fclose(f2);
    return 0;
}
